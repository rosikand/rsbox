"""
File: example.py
------------------
Example python module to test the package install. 
"""

def add_two(x):
	return x + 2
	