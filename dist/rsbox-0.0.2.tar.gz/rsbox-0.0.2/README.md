# `rsbox`: Utility Toolbox

A toolbox of utility functions [I](http://rosikand.github.io/) commonly use when programming in Python.
